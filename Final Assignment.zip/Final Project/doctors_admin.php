

<!DOCTYPE html>
<html lang="en">


<!-- doctors23:12-->
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>XYZ - Medical & Hospital - Bootstrap 4 Admin Template</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">

</head>

<body>
<div class="main-wrapper">
    <div class="header">
        <a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
        <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>
        <ul class="nav user-menu float-right">
            <li class="nav-item dropdown d-none d-sm-block">
                <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown"><i class="fa fa-bell-o"></i> <span
                        class="badge badge-pill bg-danger float-right">3</span></a>
                <div class="dropdown-menu notifications">
                    <div class="topnav-dropdown-header">
                        <span>Notifications</span>
                    </div>
                </div>
            </li>
        </ul>
        <div class="header">

            <a href="Admin.php" class="logo">
                <img src="assets/img/logo.png" width="35" height="35" alt=""> <span>XYZ</span>
            </a>
            <li class="nav-item dropdown d-none d-sm-block">
                <a href="javascript:void(0);" id="open_msg_box" class="hasnotifications nav-link"><i
                        class="fa fa-align-center"></i>
                    <span class="badge badge-pill bg-danger float-right"></span></a>
            </li>
        </div>
    </div>


        <div class="sidebar" id="sidebar">
            <div class="-sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                <ul>
                
                    <li>
                        <a href="doctors_admin.php"><i class="fa fa-user-md"></i> <span>Doctors</span></a>
                    </li>
                    <li>
                        <a href="patients.html"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
                    </li>
                
                
                    <li>
                        <a href="departments_admin.php"><i class="fa fa-hospital-o"></i> <span>Departments</span></a>
                    </li>
                    <li>
                        <form action="logout.php" method="post">
                            <button class="fa fa-user">logout</button>
                        </form>
                    </li>
                
                
                
                </ul>
                </div>
            </div>
        </div>
    </div>

<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-4 col-3">
                <h4 class="page-title">Doctors</h4>
            </div>
            <div class="col-sm-8 col-9 text-right m-b-20">
                <a href="add-doctor.html" class="btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Add Doctor</a>
            </div>
        </div>
        <?php
        $sname = "localhost";
        $uname = "root";
        $password = "";
        $db_name = "my_db";

        $conn = mysqli_connect($sname, $uname, $password, $db_name);

        if (!$conn) {
            echo "Connection Failed!";
            exit();
        }

        // SQL query to select specific columns from the "doctor" table
        $sql = "SELECT doctor_id,firstName, lastName, email, Biography, status, gender, Country, City, State FROM doctor";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo '<div class="row">';
            echo '<div class="col-md-12">';
            echo '<div class="table-responsive">';
            echo '<table class="table table-striped custom-table mb-0 datatable">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>#</th>';
            echo '<th>Doctor Id</th>';
            echo '<th>First Name</th>';
            echo '<th>Last Name</th>';
            echo '<th>Email</th>';
            echo '<th>Biography</th>';
            echo '<th>Status</th>';
            echo '<th>Gender</th>';
            echo '<th>Country</th>';
            echo '<th>City</th>';
            echo '<th>State</th>';
            echo '<th class="text-right">Action</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            $rowNumber = 1;
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $rowNumber . '</td>';
                echo '<td>' . $row["doctor_id"] . '</td>';
                echo '<td>' . $row["firstName"] . '</td>';
                echo '<td>' . $row["lastName"] . '</td>';
                echo '<td>' . $row["email"] . '</td>';
                echo '<td>' . $row["Biography"] . '</td>';
                echo '<td>' . $row["status"] . '</td>';
                echo '<td>' . $row["gender"] . '</td>';
                echo '<td>' . $row["Country"] . '</td>';
                echo '<td>' . $row["City"] . '</td>';
                echo '<td>' . $row["State"] . '</td>';
                echo '<td class="text-right">';
                echo '<div class="dropdown dropdown-action">';
                echo '<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>';
                echo '<div class="dropdown-menu dropdown-menu-right">';
                echo '<a class="dropdown-item" href="edit-doctor.html"><i class="fa fa-pencil m-r-5"></i> Edit</a>';
                echo '<a class="dropdown-item" href="delete_doctor.php?doctor_id=<?php echo $row["doctor_id"]; ?><i class="fa fa-trash-o m-r-5"></i> Delete</a>';

                echo '</div>';
                echo '</div>';
                echo '</td>';
                echo '</tr>';
                $rowNumber++;
            }

            echo '</tbody>';
            echo '</table>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        } else {
            echo "No data found";
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>
</div>


    <div class="sidebar-overlay" data-reff=""></div>
    <script src="assets/js/jquery-3.2.1.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/select2.min.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/js/app.js"></script>
</body>


<!-- doctors23:17-->
</html>