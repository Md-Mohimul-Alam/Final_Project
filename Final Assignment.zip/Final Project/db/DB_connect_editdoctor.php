<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $biography = $_POST['Biography'];
    $status = $_POST['status'];
    $gender = $_POST['gender'];
    $country = $_POST['Country'];
    $city = $_POST['City'];
    $state = $_POST['State'];
    $doctor_id = $_POST['doctor_id']; // Assuming you have a hidden input for doctor ID in your form

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'my_db');

    if ($conn->connect_error) {
        echo "Connection Failed : " . $conn->connect_error;
        exit();
    }

    // SQL query to update doctor details
    $stmt = $conn->prepare("UPDATE doctor SET firstName=?, lastName=?, email=?, Biography=?, status=?, gender=?, Country=?, City=?, State=? WHERE doctor_id=?");

    $stmt->bind_param("sssssssssi", $firstName, $lastName, $email, $biography, $status, $gender, $country, $city, $state, $doctor_id);

    if ($stmt->execute()) {
        echo "Doctor updated successfully!";
        
        header("location:\Final Project\doctors_admin.php");

    } else {
        echo "Error updating doctor: " . $conn->error;
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
}
?>
