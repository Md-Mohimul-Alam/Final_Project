<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $department_id = $_POST["department_id"];
    $department_name = $_POST["Department_Name"];
    $description = $_POST["Description"];
    $department_status = $_POST["Department_Status"];
    
    // Perform database update here, e.g., using SQL UPDATE statement
    $sname = "localhost";
    $uname = "root";
    $password = "";
    $db_name = "my_db";

    $conn = mysqli_connect($sname, $uname, $password, $db_name);

    if (!$conn) {
        echo "Connection Failed!";
        exit();
    }

    // SQL query to update department details
    $sql = "UPDATE department SET Department_Name='$department_name', Description='$description', Department_Status='$department_status' WHERE Department_ID='$department_id'";
    
    if ($conn->query($sql) === TRUE) {
        echo "Department updated successfully!";
    } else {
        echo "Error updating department: " . $conn->error;
    }
    
    // Close the database connection
    $conn->close();
}
?>
