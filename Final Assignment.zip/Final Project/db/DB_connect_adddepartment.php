<?php
	$department_id = $_POST["department_id"];
	$Department_Name = $_POST['Department_Name'];
	$Description = $_POST['Description'];
	$Department_Status = $_POST['Department_Status'];
	// Database connection
	$conn = new mysqli('localhost','root','','my_db');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("INSERT INTO department(department_id,Department_Name, Description, Department_Status) values(?, ?, ?, ?)");
		$stmt->bind_param("isss", $department_id, $Department_Name, $Description, $Department_Status);
		$execval = $stmt->execute();
		echo $execval;
		echo "Created successfully...";
		
		$stmt->close();
		$conn->close();
	}
?>