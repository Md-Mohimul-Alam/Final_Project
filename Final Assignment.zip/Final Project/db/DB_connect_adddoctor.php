<?php
	$doctor_id = $_POST['doctor_id'];
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
    $username = $_POST['username'];
    $email = $_POST['email'];
	$password = $_POST['password'];
	$DOB = $_POST['DOB'];
    $gender = $_POST['gender'];
	$Address = $_POST['Address'];
    $Country = $_POST['Country'];
    $City = $_POST['City'];
    $State = $_POST['State'];
    $Postal_Code = $_POST['Postal_Code'];
    $Phone = $_POST['Phone'];
    $Biography = $_POST['Biography'];
    $status = $_POST['status'];
    

	// Database connection
	$conn = new mysqli('localhost','root','','my_db');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("INSERT INTO doctor(doctor_id,firstName, lastName, username,email,password,DOB,gender,Address,Country,City,State,Postal_Code,Phone, Biography,status) values(?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?)");
		$stmt->bind_param("isssssdsssssiiss", $doctor_id, $firstName, $firstName, $username, $email, $password, $DOB, $gender, $Address, $Country, $City, $State, $Postal_Code, $Phone, $Biography, $status);
		$execval = $stmt->execute();
		echo $execval;
		echo "Created successfully...";
		header( "location: Final Project\doctors_admin.php");
		$stmt->close();
		$conn->close();
	}
?>