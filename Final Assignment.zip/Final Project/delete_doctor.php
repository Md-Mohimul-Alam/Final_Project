<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["doctor_id"])) {
    $doctor_id = $_GET["doctor_id"]; // Get the doctor_id from the URL parameter

    // Database connection
    $sname = "localhost";
    $uname = "root";
    $password = "";
    $db_name = "my_db";

    $conn = mysqli_connect($sname, $uname, $password, $db_name);

    if (!$conn) {
        echo "Connection Failed!";
        exit();
    }

    // SQL query to delete the doctor record
    $sql = "DELETE FROM doctor WHERE doctor_id = '$doctor_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Doctor deleted successfully!";
    } else {
        echo "Error deleting doctor: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
