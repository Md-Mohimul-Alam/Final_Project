
<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Authenticate user (perform database query to validate credentials)
    $sname = "localhost";
    $uname = "root";
    $db_password = ""; // Replace with your database password
    $db_name = "my_db";

    $conn = mysqli_connect($sname, $uname, $db_password, $db_name);

    if (!$conn) {
        echo "Connection Failed!";
        exit();
    }

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $_SESSION["user_id"] = $row["user_id"];
        $_SESSION["role"] = $row["role"];
        header("Location: dash.php"); // Redirect to the appropriate page after login
        exit();
    } else {
        echo "Login failed. Please check your credentials.";
    }

    $conn->close();
}
?>
