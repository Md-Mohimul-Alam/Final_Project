// dashboard.php
<?php
session_start();



// Check the user's role
$userRole = $_SESSION["role"];

if ($userRole === "doctor") {
    // Display doctor-specific content and actions
    // Modify the code for doctors here
    header("location: Doctors.php");

} elseif ($userRole === "admin") {
    // Display admin-specific content and actions
    // Modify the code for admins here
    header("Location: Admin.php");
} else {
    // Handle other roles or unauthorized access
    echo "Unauthorized access.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... Your HTML head content ... -->
</head>
<body>
    <!-- ... Your HTML body content ... -->
</body>
</html>
