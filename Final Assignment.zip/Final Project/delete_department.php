<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["department_id"])) {
    $department_id = $_GET["department_id"]; // Get the department_id from the URL parameter

    // Database connection
    $sname = "localhost";
    $uname = "root";
    $password = "";
    $db_name = "my_db";

    $conn = mysqli_connect($sname, $uname, $password, $db_name);

    if (!$conn) {
        echo "Connection Failed!";
        exit();
    }

    // SQL query to delete the department record
    $sql = "DELETE FROM department WHERE Department_Id = '$department_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Department deleted successfully!";
    } else {
        echo "Error deleting department: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
