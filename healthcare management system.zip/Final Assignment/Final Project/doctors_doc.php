
<!DOCTYPE html>
<html lang="en">



<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>XYZ - Medical & Hospital - Bootstrap 4 Admin Template</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" href="css\button.css">

</head>

<body>
    <div class="main-wrapper">
        <div class="header">

			<a href="Admin.php" class="logo">
				<img src="assets/img/logo.png" width="50" height="50" alt=""> <span>XYZ</span>
			</a>            
			
        </div>
       
        <div class="container">
            <a class="button" href="doctors_doc_D.php" style="--color:#1e9bff;">
                <i class="fa fa-user-md">Doctors</i> 
            </a>

            <a class="button" href="patients_doc.html" style="--color:#1e9bff;">
                <i class="fa fa-wheelchair">Patients</i> 
            </a>

            <a class="button" href="departments_doc.php" style="--color:#1e9bff;">
                <i class="fa fa-calendar-check-o">Department</i> 
            </a>
        
            <a class="button" href="logout.php" method="post" style="--color:#1e9bff;">
               <i class="fa fa-user">logout</i> 
            </a>
        </div>


    </div>

   

</body>



</html>
