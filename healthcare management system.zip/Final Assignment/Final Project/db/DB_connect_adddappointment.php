<?php
	$p_name = $_POST['p_name'];
	$Department_name = $_POST['Department_name'];
    $Doctor = $_POST['Doctor'];
    $Date = $_POST['Date'];
	$Time = $_POST['Time'];
	$email = $_POST['email'];
    $Phone = $_POST['Phone'];
	$Message = $_POST['Message'];
    $Doctor_Status = $_POST['Doctor_Status'];

	// Database connection
	$conn = new mysqli('localhost','root','','my_db');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("INSERT INTO appointment(id, p_name, Department_name, Doctor,Date,Time,email,Phone,Message,Doctor_Status) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("issssssiss", $id, $p_name, $Department_name, $Doctor, $Date, $Time, $email, $Phone, $Message, $Doctor_Status);
		$execval = $stmt->execute();
		echo $execval;
		echo "Created successfully...";
		$stmt->close();
		$conn->close();
	}
?>