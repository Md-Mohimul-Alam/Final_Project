<?php
	$name = $_POST['name'];
	$email = $_POST['email'];
	$text = $_POST['text'];
	
	// Database connection
	$conn = new mysqli('localhost','root','','my_db');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("INSERT INTO contact(name, email, text) values(?, ?, ?)");
		$stmt->bind_param("sss", $name, $email, $text);
		$execval = $stmt->execute();
		echo $execval;
		echo "sended successfully...";
		$stmt->close();
		$conn->close();
	}
?>