# How to Make Multi User Role Based Login Form in PHP and MySQL

version: 1.0.0

### UserName : elias

### Password : 1234

### UserType : Admin

### ---------------------------------

### UserName : john

### Password : abcd

### UserType : user

## Full Tutorial

[On Youtube](https://youtu.be/-8q3GLkr9Ts)

## Authors

[Elias Abdurrahman](https://github.com/codingWithElias)
